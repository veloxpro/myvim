function foo() {
    return x;
}

var bar = function() {
    return y;
};

function baz() { // foo
    return z;
}

function baz() {
    return 1;
}

